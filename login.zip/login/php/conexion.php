
<?php 
  $server1 = "localhost";
  $usuario = "root";
  $contra = "";
  $db = "intecap";
  $usuario_Conex = mysqli_connect($server1, $usuario, $contra, $db);
?>
